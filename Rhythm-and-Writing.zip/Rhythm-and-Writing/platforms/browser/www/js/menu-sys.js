$("#practice-btn").on("click", function() {
   $.mobile.loadPage("/www/pic-lesson.html");
});